% LOHC_EE_PSO.m - Particle Swarm Optimization for Energy System Simulation

clc
clear
close all

%% Initial Setup and Data Loading
LifeTime = 30; % Lifetime of project

% Input data (replace with actual file paths and data)
PrimeLoad = 73030.568 * ones(8760, 1);
PrimeHLoad = 8884.069 * ones(8760, 1);
CompLoad = 2899.2897 * ones(8760, 1);
EleZ = readmatrix('EZLoad.xlsx');
Electrolyzer_load = EleZ(:, 20);
resources = readmatrix('texaspv.xlsx') + readmatrix('texaswind');

% Precompute resource adjustments
A = zeros(7885, 1);
for k = 1:7885
    A(k) = sum(resources(k:k+875));
end
D = min(A);
AA = find(A == D);
AAA = AA(1);
B = ones(size(resources));
for j = AAA:AAA+875
    B(j) = 0;
end

Load1 = PrimeLoad .* B;
HLoad1 = PrimeHLoad .* B;
primethermal = 21500 * B * 1.05;
HStoreLoad = CompLoad .* B;

% Prepare lifetime data
Load = repmat(Load1 + HStoreLoad, LifeTime, 1) + Electrolyzer_load;
HLoad = max((repmat(HLoad1, LifeTime, 1) - 1/43.5 * Electrolyzer_load), 0);
thermal_H2DRI = repmat(primethermal, LifeTime, 1);
Load(1:48) = 0;
HLoad(1:48) = 0;
thc = 11.383 * HLoad + thermal_H2DRI;

homerpv = repmat(readmatrix('texaspv.xlsx'), LifeTime, 1);
homerwt = repmat(readmatrix('texaswind'), LifeTime, 1);

% Component and operation prices
CB = 369; CPV = 1248; CWT = 1268; CTH = 2; CTH_electric_heater = 2500000;
BLT = 10; EZLT = 10; pf = 5; hpf = 10; tpf = 1;
P1 = 100000000; P2 = 100; P3 = 10; P4 = 1;
deg = 0.9999; OMPV = 20.5; OMWT = 28.8; OMB = 2.5; OMEL = 10; OMTH = 0.0017;
inflation = 0.02; intrest = 0.06; discount = 1 - (intrest - inflation) / (inflation + 1);
Heff = 1/43.5; Leff = 1/55; CPz = 1500; reCPz = 450; cutin = 0.1;
rectifier_eff = 0.97; inverter_eff = 0.97;

% Store data in a structure
data = struct('LifeTime', LifeTime, 'Load', Load, 'HLoad', HLoad, 'thc', thc, ...
    'homerpv', homerpv, 'homerwt', homerwt, 'Electrolyzer_load', Electrolyzer_load, ...
    'CB', CB, 'CPV', CPV, 'CWT', CWT, 'CTH', CTH, 'CTH_electric_heater', CTH_electric_heater, ...
    'BLT', BLT, 'EZLT', EZLT, 'pf', pf, 'hpf', hpf, 'tpf', tpf, ...
    'P1', P1, 'P2', P2, 'P3', P3, 'P4', P4, 'deg', deg, ...
    'OMPV', OMPV, 'OMWT', OMWT, 'OMB', OMB, 'OMEL', OMEL, 'OMTH', OMTH, ...
    'discount', discount, 'Heff', Heff, 'Leff', Leff, 'CPz', CPz, 'reCPz', reCPz, ...
    'cutin', cutin, 'rectifier_eff', rectifier_eff, 'inverter_eff', inverter_eff);

%% Define Objective Function for PSO
objective = @(variables) simulate_system(variables, data);

%% PSO Optimization
lb = [100000, 100000, 100000, 200000, 100000, 7000000]; % Lower bounds
ub = [800000, 1500000, 1500000, 2900000, 1300000, 8900000]; % Upper bounds
options = optimoptions('particleswarm', 'SwarmSize', 50, 'MaxIterations', 100, 'Display', 'iter');

[best_variables, best_cost] = particleswarm(objective, 6, lb, ub, options);

%% Extract Results
[~, outputs] = simulate_system(best_variables, data);

% Display results
solution = ['CapF= ', num2str(outputs.CapacityFactorReal), ...
    ' PVbest= ', num2str(outputs.PV), ' WTBest= ', num2str(outputs.WT), ...
    ' Bbest= ', num2str(outputs.ZB), ' ElectrolyzerBest=', num2str(outputs.Pel), ...
    ' HTbest= ', num2str(outputs.HTmax), ' THSmaxbest= ', num2str(outputs.THSmax)];
costs = ['LCSP= ', num2str(outputs.LCSP), ', OF= ', num2str(outputs.ObjectiveFunction)];
disp(solution)
disp(costs)

%% Generate Figures
% Figure 1: Winter
figure(1);
set(gcf, 'Position', [100, 100, 1000, 800]);
subplot(2,1,1);
yyaxis left
plot(outputs.SOC(60:204), 'Color', [0.2, 0.6, 0.2], 'LineWidth', 1.5);
hold on
plot(outputs.WT_Production(60:204), 'Color', [0, 0.4, 0.8], 'LineWidth', 2);
plot(outputs.PV_Production(60:204), 'Color', [1, 0.8, 0], 'LineWidth', 3);
plot(outputs.ExcessElectricity(60:204), 'Color', [0.8, 0.1, 0.1], 'LineWidth', 1.5);
ylabel('Production, Storage, and Excess (kW)', 'FontSize', 14, 'FontWeight', 'Bold');
yyaxis right
plot(outputs.SEL(60:204), 'Color', [0, 0, 0], 'LineWidth', 2);
ylabel('Load (kW)', 'FontSize', 14, 'FontWeight', 'Bold');
legend('SOC', 'WT', 'PV', 'Excess', 'Load', 'FontSize', 12, 'FontWeight', 'Bold', 'Location', 'best');
xlabel('Time (h)', 'FontSize', 14, 'FontWeight', 'Bold');
title('Electricity - Winter', 'FontSize', 14, 'FontWeight', 'Bold');
grid on;
ax = gca;
ax.FontWeight = 'Bold';
ax.FontSize = 14;

subplot(2,1,2);
yyaxis left
plot(outputs.PEZ(60:204), '-*', 'Color', [0, 0.5, 0.8], 'LineWidth', 1);
hold on
plot(outputs.SHL(60:204), 'Color', [0.9, 0.3, 0.3], 'LineWidth', 2.5);
ylabel('Electrolyzer & Hydrogen Load (kg)', 'FontSize', 14, 'FontWeight', 'Bold');
yyaxis right
plot(outputs.SOH(60:204), 'Color', [0.4, 0.7, 0.2], 'LineWidth', 1.5);
ylabel('Hydrogen Tank (kg)', 'FontSize', 14, 'FontWeight', 'Bold');
legend('Electrolyzer', 'HLoad', 'HT', 'FontSize', 12, 'FontWeight', 'Bold', 'Location', 'best');
xlabel('Time (h)', 'FontSize', 14, 'FontWeight', 'Bold');
title('Hydrogen System - Winter', 'FontSize', 14, 'FontWeight', 'Bold');
grid on;
ax = gca;
ax.FontWeight = 'Bold';
ax.FontSize = 14;

% Figure 2: Spring
figure(2);
set(gcf, 'Position', [100, 100, 1000, 800]);
subplot(2,1,1);
yyaxis left
plot(outputs.SOC(2300:2454), 'Color', [0.2, 0.6, 0.2], 'LineWidth', 1.5);
hold on
plot(outputs.WT_Production(2300:2454), 'Color', [0, 0.4, 0.8], 'LineWidth', 2);
plot(outputs.PV_Production(2300:2454), 'Color', [1, 0.8, 0], 'LineWidth', 3);
plot(outputs.ExcessElectricity(2300:2454), 'Color', [0.8, 0.1, 0.1], 'LineWidth', 1.5);
ylabel('Production, Storage, and Excess (kW)', 'FontSize', 14, 'FontWeight', 'Bold');
yyaxis right
plot(outputs.SEL(2300:2454), 'Color', [0, 0, 0], 'LineWidth', 2);
ylabel('Load (kW)', 'FontSize', 14, 'FontWeight', 'Bold');
legend('SOC', 'WT', 'PV', 'Excess', 'Load', 'FontSize', 12, 'FontWeight', 'Bold', 'Location', 'best');
xlabel('Time (h)', 'FontSize', 14, 'FontWeight', 'Bold');
title('Electricity - Spring', 'FontSize', 14, 'FontWeight', 'Bold');
grid on;
ax = gca;
ax.FontWeight = 'Bold';
ax.FontSize = 14;

subplot(2,1,2);
yyaxis left
plot(outputs.PEZ(2300:2454), '-*', 'Color', [0, 0.5, 0.8], 'LineWidth', 1);
hold on
plot(outputs.SHL(2300:2454), 'Color', [0.9, 0.3, 0.3], 'LineWidth', 2.5);
ylabel('Electrolyzer & Hydrogen Load (kg)', 'FontSize', 14, 'FontWeight', 'Bold');
yyaxis right
plot(outputs.SOH(2300:2454), 'Color', [0.4, 0.7, 0.2], 'LineWidth', 1.5);
ylabel('Hydrogen Tank (kg)', 'FontSize', 14, 'FontWeight', 'Bold');
legend('Electrolyzer', 'HLoad', 'HT', 'FontSize', 12, 'FontWeight', 'Bold', 'Location', 'best');
xlabel('Time (h)', 'FontSize', 14, 'FontWeight', 'Bold');
title('Hydrogen System - Spring', 'FontSize', 14, 'FontWeight', 'Bold');
grid on;
ax = gca;
ax.FontWeight = 'Bold';
ax.FontSize = 14;

% Figure 3: Summer
figure(3);
set(gcf, 'Position', [100, 100, 1000, 800]);
subplot(2,1,1);
yyaxis left
plot(outputs.SOC(4300:4454), 'Color', [0.2, 0.6, 0.2], 'LineWidth', 1.5);
hold on
plot(outputs.WT_Production(4300:4454), 'Color', [0, 0.4, 0.8], 'LineWidth', 2);
plot(outputs.PV_Production(4300:4454), 'Color', [1, 0.8, 0], 'LineWidth', 3);
plot(outputs.ExcessElectricity(4300:4454), 'Color', [0.8, 0.1, 0.1], 'LineWidth', 1.5);
ylabel('Production, Storage, and Excess (kW)', 'FontSize', 14, 'FontWeight', 'Bold');
yyaxis right
plot(outputs.SEL(4300:4454), 'Color', [0, 0, 0], 'LineWidth', 2);
ylabel('Load (kW)', 'FontSize', 14, 'FontWeight', 'Bold');
legend('SOC', 'WT', 'PV', 'Excess', 'Load', 'FontSize', 12, 'FontWeight', 'Bold', 'Location', 'best');
xlabel('Time (h)', 'FontSize', 14, 'FontWeight', 'Bold');
title('Electricity - Summer', 'FontSize', 14, 'FontWeight', 'Bold');
grid on;
ax = gca;
ax.FontWeight = 'Bold';
ax.FontSize = 14;

subplot(2,1,2);
yyaxis left
plot(outputs.PEZ(4300:4454), '-*', 'Color', [0, 0.5, 0.8], 'LineWidth', 1);
hold on
plot(outputs.SHL(4300:4454), 'Color', [0.9, 0.3, 0.3], 'LineWidth', 2.5);
ylabel('Electrolyzer & Hydrogen Load (kg)', 'FontSize', 14, 'FontWeight', 'Bold');
yyaxis right
plot(outputs.SOH(4300:4454), 'Color', [0.4, 0.7, 0.2], 'LineWidth', 1.5);
ylabel('Hydrogen Tank (kg)', 'FontSize', 14, 'FontWeight', 'Bold');
legend('Electrolyzer', 'HLoad', 'HT', 'FontSize', 12, 'FontWeight', 'Bold', 'Location', 'best');
xlabel('Time (h)', 'FontSize', 14, 'FontWeight', 'Bold');
title('Hydrogen System - Summer', 'FontSize', 14, 'FontWeight', 'Bold');
grid on;
ax = gca;
ax.FontWeight = 'Bold';
ax.FontSize = 14;

% Figure 4: Fall
figure(4);
set(gcf, 'Position', [100, 100, 1000, 800]);
subplot(2,1,1);
yyaxis left
plot(outputs.SOC(6300:6454), 'Color', [0.2, 0.6, 0.2], 'LineWidth', 1.5);
hold on
plot(outputs.WT_Production(6300:6454), 'Color', [0, 0.4, 0.8], 'LineWidth', 2);
plot(outputs.PV_Production(6300:6454), 'Color', [1, 0.8, 0], 'LineWidth', 3);
plot(outputs.ExcessElectricity(6300:6454), 'Color', [0.8, 0.1, 0.1], 'LineWidth', 1.5);
ylabel('Production, Storage, and Excess (kW)', 'FontSize', 14, 'FontWeight', 'Bold');
yyaxis right
plot(outputs.SEL(6300:6454), 'Color', [0, 0, 0], 'LineWidth', 2);
ylabel('Load (kW)', 'FontSize', 14, 'FontWeight', 'Bold');
legend('SOC', 'WT', 'PV', 'Excess', 'Load', 'FontSize', 12, 'FontWeight', 'Bold', 'Location', 'best');
xlabel('Time (h)', 'FontSize', 14, 'FontWeight', 'Bold');
title('Electricity - Fall', 'FontSize', 14, 'FontWeight', 'Bold');
grid on;
ax = gca;
ax.FontWeight = 'Bold';
ax.FontSize = 14;

subplot(2,1,2);
yyaxis left
plot(outputs.PEZ(6300:6454), '-*', 'Color', [0, 0.5, 0.8], 'LineWidth', 1);
hold on
plot(outputs.SHL(6300:6454), 'Color', [0.9, 0.3, 0.3], 'LineWidth', 2.5);
ylabel('Electrolyzer & Hydrogen Load (kg)', 'FontSize', 14, 'FontWeight', 'Bold');
yyaxis right
plot(outputs.SOH(6300:6454), 'Color', [0.4, 0.7, 0.2], 'LineWidth', 1.5);
ylabel('Hydrogen Tank (kg)', 'FontSize', 14, 'FontWeight', 'Bold');
legend('Electrolyzer', 'HLoad', 'HT', 'FontSize', 12, 'FontWeight', 'Bold', 'Location', 'best');
xlabel('Time (h)', 'FontSize', 14, 'FontWeight', 'Bold');
title('Hydrogen System - Fall', 'FontSize', 14, 'FontWeight', 'Bold');
grid on;
ax = gca;
ax.FontWeight = 'Bold';
ax.FontSize = 14;

%% Define Simulation Function
function [NewObjectiveFunction, outputs] = simulate_system(variables, data)
    % Unpack variables
    PV = variables(1);
    WT = variables(2);
    Pel = variables(3);
    ZB = variables(4);
    HTmax = variables(5);
    THSmax = variables(6);

    % Extract data
    LifeTime = data.LifeTime;
    Load = data.Load;
    HLoad = data.HLoad;
    thc = data.thc;
    homerpv = data.homerpv;
    homerwt = data.homerwt;
    Electrolyzer_load = data.Electrolyzer_load;
    CB = data.CB; CPV = data.CPV; CWT = data.CWT; CTH = data.CTH;
    CTH_electric_heater = data.CTH_electric_heater; BLT = data.BLT;
    EZLT = data.EZLT; pf = data.pf; hpf = data.hpf; tpf = data.tpf;
    P1 = data.P1; P2 = data.P2; P3 = data.P3; P4 = data.P4; degrad = data.deg;
    OMPV = data.OMPV; OMWT = data.OMWT; OMB = data.OMB; OMEL = data.OMEL;
    OMTH = data.OMTH; discount = data.discount; Heff = data.Heff;
    Leff = data.Leff; CPz = data.CPz; reCPz = data.reCPz; cutin = data.cutin;
    rectifier_eff = data.rectifier_eff; inverter_eff = data.inverter_eff;

    % Initialize arrays
    PWT = zeros(8760 * LifeTime, 1);
    PPV = zeros(8760 * LifeTime, 1);
    EB = zeros(8760 * LifeTime, 1);
    LPS = zeros(8760 * LifeTime, 1);
    Excess = zeros(8760 * LifeTime, 1);
    LHS = zeros(8760 * LifeTime, 1);
    HT = zeros(8760 * LifeTime, 1);
    Electrolyzer = zeros(8760 * LifeTime, 1);
    ths = zeros(8760 * LifeTime, 1);
    LTS = zeros(8760 * LifeTime, 1);
    OM = zeros(LifeTime, 1);
    EZLoad = zeros(8760 * LifeTime, 1);
    HH = zeros(8737, 1);
    AS = zeros(8760 * LifeTime, 1);
    H1prod = zeros(4, 1);

    % Simulation over lifetime
    for year = 1:LifeTime
        for i = 2:8760
            EB(1) = 0;
            HT(1) = 0;
            ths(1) = 0;
            iteration = i + 8760 * (year - 1);

            CCB = CB * ZB;
            CCPV = CPV * PV;
            CCWT = CWT * WT;
            CCPz = Pel * CPz;
            CCTH = THSmax * CTH;
            PZ = Pel * (degrad^(year - 1));
            Active_area = 1000 * PZ / 2 * 1.9;

            PPV(iteration) = inverter_eff * homerpv(iteration) * PV * (degrad^(year - 1));
            PWT(iteration) = rectifier_eff * homerwt(iteration) * WT * (degrad^(year - 1));

            % Dispatching logic
            if PPV(iteration) + PWT(iteration) - Load(iteration) >= 0
                if HT(iteration - 1) < HLoad(iteration)
                    if PPV(iteration) + PWT(iteration) < Load(iteration) + cutin * PZ
                        if PPV(iteration) + PWT(iteration) + EB(iteration - 1) < Load(iteration) + cutin * PZ
                            EB(iteration) = min(PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1), ZB);
                            LPS(iteration) = 0;
                            LHS(iteration) = max(0, HLoad(iteration) - HT(iteration - 1));
                            HT(iteration) = 0;
                            Electrolyzer(iteration) = 0;
                            Excess(iteration) = max(PPV(iteration) + PWT(iteration) - Load(iteration) - (ZB - EB(iteration - 1)), 0);
                            ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                            LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                        elseif PPV(iteration) + PWT(iteration) + EB(iteration - 1) >= Load(iteration) + cutin * PZ
                            EB(iteration) = max(min(PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - cutin * PZ, ZB), 0);
                            LPS(iteration) = 0;
                            LHS(iteration) = max(HLoad(iteration) - cutin * Heff * PZ - HT(iteration - 1), 0);
                            HT(iteration) = min(max(cutin * Heff * PZ + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                            Electrolyzer(iteration) = cutin * Heff * PZ;
                            Excess(iteration) = 0;
                            ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                            LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                        end
                    elseif (PPV(iteration) + PWT(iteration) >= Load(iteration) + cutin * PZ) && ((PPV(iteration) + PWT(iteration) <= Load(iteration) + PZ))
                        for n = 2:4
                            H1prod(1) = (PPV(iteration) + PWT(iteration) - Load(iteration)) / (6.39 * 2 * ((PPV(iteration) + PWT(iteration) - Load(iteration)) / PZ) + 42.22);
                            H1prod(n) = (PPV(iteration) + PWT(iteration) - Load(iteration)) / (6.39 * (H1prod(n - 1) * 2 * 96485 / (0.002016 * 3600 * Active_area)) + 42.22);
                        end
                        EB(iteration) = EB(iteration - 1);
                        LPS(iteration) = 0;
                        LHS(iteration) = max(HLoad(iteration) - H1prod(n) - HT(iteration - 1), 0);
                        HT(iteration) = min(max(H1prod(n) + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                        Electrolyzer(iteration) = H1prod(n);
                        Excess(iteration) = 0;
                        ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                        LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                    elseif (PPV(iteration) + PWT(iteration) > Load(iteration) + PZ) && ((PPV(iteration) + PWT(iteration) <= Load(iteration) + PZ + ZB - EB(iteration - 1)))
                        H1prod = Leff * PZ;
                        EB(iteration) = EB(iteration - 1) + PPV(iteration) + PWT(iteration) - Load(iteration) - PZ;
                        LPS(iteration) = 0;
                        HT(iteration) = min(max(H1prod + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                        Electrolyzer(iteration) = H1prod;
                        Excess(iteration) = 0;
                        ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                        LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                    elseif (PPV(iteration) + PWT(iteration)) > (Load(iteration) + PZ + ZB - EB(iteration - 1))
                        H1prod = Leff * PZ;
                        EB(iteration) = ZB;
                        LPS(iteration) = 0;
                        LHS(iteration) = max(HLoad(iteration) - H1prod - HT(iteration - 1), 0);
                        HT(iteration) = min(max(H1prod + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                        Electrolyzer(iteration) = H1prod;
                        Excess(iteration) = PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - ZB - PZ;
                        ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                        LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                    end
                elseif HT(iteration - 1) >= HLoad(iteration)
                    if pf * Load(iteration) / (EB(iteration - 1) + 0.01) < hpf * HLoad(iteration) / (HT(iteration - 1) + 0.01)
                        if PPV(iteration) + PWT(iteration) < Load(iteration) + cutin * PZ
                            if PPV(iteration) + PWT(iteration) + EB(iteration - 1) < Load(iteration) + cutin * PZ
                                EB(iteration) = min(PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1), ZB);
                                LPS(iteration) = 0;
                                LHS(iteration) = max(0, HLoad(iteration) - HT(iteration - 1));
                                HT(iteration) = min(max(HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                                Electrolyzer(iteration) = 0;
                                Excess(iteration) = max(PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - ZB, 0);
                                ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                                LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                            elseif PPV(iteration) + PWT(iteration) + EB(iteration - 1) >= Load(iteration) + cutin * PZ
                                EB(iteration) = min(PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - cutin * PZ, ZB);
                                LPS(iteration) = 0;
                                LHS(iteration) = max(HLoad(iteration) - cutin * Heff * PZ - HT(iteration - 1), 0);
                                HT(iteration) = min(max(cutin * Heff * PZ + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                                Electrolyzer(iteration) = cutin * Heff * PZ;
                                Excess(iteration) = 0;
                                ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                                LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                            end
                        elseif (PPV(iteration) + PWT(iteration) >= Load(iteration) + cutin * PZ) && ((PPV(iteration) + PWT(iteration) <= Load(iteration) + PZ))
                            for n = 2:4
                                H1prod(1) = (PPV(iteration) + PWT(iteration) - Load(iteration)) / (6.39 * 2 * ((PPV(iteration) + PWT(iteration) - Load(iteration)) / PZ) + 42.22);
                                H1prod(n) = (PPV(iteration) + PWT(iteration) - Load(iteration)) / (6.39 * (H1prod(n - 1) * 2 * 96485 / (0.002016 * 3600 * Active_area)) + 42.22);
                            end
                            EB(iteration) = EB(iteration - 1);
                            LPS(iteration) = 0;
                            LHS(iteration) = max(HLoad(iteration) - H1prod(n) - HT(iteration - 1), 0);
                            HT(iteration) = min(max(H1prod(n) + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                            Electrolyzer(iteration) = H1prod(n);
                            Excess(iteration) = 0;
                            ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                            LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                        elseif (PPV(iteration) + PWT(iteration) > Load(iteration) + PZ) && ((PPV(iteration) + PWT(iteration) <= Load(iteration) + PZ + ZB - EB(iteration - 1)))
                            H1prod = Leff * PZ;
                            EB(iteration) = EB(iteration - 1) + PPV(iteration) + PWT(iteration) - Load(iteration) - PZ;
                            LPS(iteration) = 0;
                            LHS(iteration) = max(HLoad(iteration) - H1prod - HT(iteration - 1), 0);
                            HT(iteration) = min(max(H1prod + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                            Electrolyzer(iteration) = H1prod;
                            Excess(iteration) = 0;
                            ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                            LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                        elseif (PPV(iteration) + PWT(iteration)) > (Load(iteration) + PZ + ZB - EB(iteration - 1))
                            H1prod = Leff * PZ;
                            EB(iteration) = ZB;
                            LPS(iteration) = 0;
                            LHS(iteration) = max(HLoad(iteration) - H1prod - HT(iteration - 1), 0);
                            HT(iteration) = min(max(H1prod + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                            Electrolyzer(iteration) = H1prod;
                            Excess(iteration) = PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - ZB - PZ;
                            ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                            LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                        end
                    elseif pf * Load(iteration) / (EB(iteration - 1) + 0.01) >= hpf * HLoad(iteration) / (HT(iteration - 1) + 0.01)
                        if PPV(iteration) + PWT(iteration) < Load(iteration) + ZB - EB(iteration - 1)
                            EB(iteration) = PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1);
                            LPS(iteration) = 0;
                            LHS(iteration) = 0;
                            HT(iteration) = min(max(HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                            Electrolyzer(iteration) = 0;
                            Excess(iteration) = 0;
                            ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                            LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                        elseif PPV(iteration) + PWT(iteration) >= Load(iteration) + ZB - EB(iteration - 1)
                            if PPV(iteration) + PWT(iteration) < Load(iteration) + ZB - EB(iteration - 1) + cutin * PZ
                                if PPV(iteration) + PWT(iteration) >= Load(iteration) + cutin * PZ
                                    EB(iteration) = PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - cutin * PZ;
                                    LPS(iteration) = 0;
                                    LHS(iteration) = 0;
                                    HT(iteration) = min(HT(iteration - 1) - HLoad(iteration) + cutin * Heff * PZ, HTmax);
                                    Electrolyzer(iteration) = cutin * Heff * PZ;
                                    Excess(iteration) = max(PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - ZB - cutin * PZ, 0);
                                    ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                                    LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                                elseif PPV(iteration) + PWT(iteration) < Load(iteration) + cutin * PZ
                                    EB(iteration) = ZB;
                                    LPS(iteration) = 0;
                                    LHS(iteration) = 0;
                                    HT(iteration) = min(max((HT(iteration - 1) - HLoad(iteration)), 0), HTmax);
                                    Electrolyzer(iteration) = 0;
                                    Excess(iteration) = max(PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - ZB, 0);
                                    ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                                    LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                                end
                            elseif (PPV(iteration) + PWT(iteration) >= Load(iteration) + cutin * PZ) && ((PPV(iteration) + PWT(iteration) <= Load(iteration) + PZ))
                                for n = 2:4
                                    H1prod(1) = (PPV(iteration) + PWT(iteration) - Load(iteration)) / (6.39 * 2 * ((PPV(iteration) + PWT(iteration) - Load(iteration)) / PZ) + 42.22);
                                    H1prod(n) = (PPV(iteration) + PWT(iteration) - Load(iteration)) / (6.39 * (H1prod(n - 1) * 2 * 96485 / (0.002016 * 3600 * Active_area)) + 42.22);
                                end
                                EB(iteration) = EB(iteration - 1);
                                LPS(iteration) = 0;
                                LHS(iteration) = max(HLoad(iteration) - H1prod(n) - HT(iteration - 1), 0);
                                HT(iteration) = min(max(H1prod(n) + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                                Electrolyzer(iteration) = H1prod(n);
                                Excess(iteration) = 0;
                                ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                                LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                            elseif (PPV(iteration) + PWT(iteration) > Load(iteration) + PZ) && ((PPV(iteration) + PWT(iteration) <= Load(iteration) + PZ + ZB - EB(iteration - 1)))
                                H1prod = Leff * PZ;
                                EB(iteration) = EB(iteration - 1) + PPV(iteration) + PWT(iteration) - Load(iteration) - PZ;
                                LPS(iteration) = 0;
                                LHS(iteration) = max(HLoad(iteration) - H1prod - HT(iteration - 1), 0);
                                HT(iteration) = min(max(H1prod + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                                Electrolyzer(iteration) = H1prod;
                                Excess(iteration) = 0;
                                ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                                LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                            elseif (PPV(iteration) + PWT(iteration)) > (Load(iteration) + PZ + ZB - EB(iteration - 1))
                                H1prod = Leff * PZ;
                                EB(iteration) = ZB;
                                LPS(iteration) = 0;
                                LHS(iteration) = max(HLoad(iteration) - H1prod - HT(iteration - 1), 0);
                                HT(iteration) = min(max(H1prod + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                                Electrolyzer(iteration) = H1prod;
                                Excess(iteration) = PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - ZB - PZ;
                                ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                                LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                            end
                        end
                    end
                end
            elseif PPV(iteration) + PWT(iteration) - Load(iteration) < 0
                if EB(iteration - 1) >= Load(iteration) - PPV(iteration) - PWT(iteration)
                    if HT(iteration - 1) >= HLoad(iteration)
                        EB(iteration) = PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1);
                        LPS(iteration) = 0;
                        LHS(iteration) = 0;
                        HT(iteration) = min(max(HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                        Electrolyzer(iteration) = 0;
                        Excess(iteration) = 0;
                        ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                        LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                    elseif HT(iteration - 1) < HLoad(iteration)
                        if PPV(iteration) + PWT(iteration) + EB(iteration - 1) > Load(iteration) + cutin * PZ
                            EB(iteration) = PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1) - cutin * PZ;
                            LPS(iteration) = 0;
                            LHS(iteration) = max(HLoad(iteration) - cutin * Heff * PZ - HT(iteration - 1), 0);
                            HT(iteration) = min(max(cutin * Heff * PZ + HT(iteration - 1) - HLoad(iteration), 0), HTmax);
                            Electrolyzer(iteration) = cutin * Heff * PZ;
                            Excess(iteration) = 0;
                            ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                            LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                        elseif PPV(iteration) + PWT(iteration) + EB(iteration - 1) < Load(iteration) + cutin * PZ
                            EB(iteration) = PPV(iteration) + PWT(iteration) - Load(iteration) + EB(iteration - 1);
                            LPS(iteration) = 0;
                            LHS(iteration) = max(0, HLoad(iteration) - HT(iteration - 1));
                            HT(iteration) = 0;
                            Electrolyzer(iteration) = 0;
                            Excess(iteration) = 0;
                            ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                            LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                        end
                    end
                elseif EB(iteration - 1) < Load(iteration) - PPV(iteration) - PWT(iteration)
                    EB(iteration) = 0;
                    LPS(iteration) = max(0, Load(iteration) - PPV(iteration) - PWT(iteration) - EB(iteration - 1));
                    LHS(iteration) = max(0, HLoad(iteration) - HT(iteration - 1));
                    HT(iteration) = min(max(0, HT(iteration - 1) - HLoad(iteration)), HTmax);
                    Electrolyzer(iteration) = 0;
                    Excess(iteration) = 0;
                    ths(iteration) = max(min((Excess(iteration) + ths(iteration - 1) - thc(iteration)), THSmax), 0);
                    LTS(iteration) = max(0, (thc(iteration) - Excess(iteration) - ths(iteration - 1)));
                end
            end

            HT(1 + 8760 * year) = HT(8760 * year);
            EB(1 + 8760 * year) = EB(8760 * year);
            ths(1 + 8760 * year) = ths(8760 * year);

            if HT(iteration) < HT(iteration - 1)
                AS(iteration) = HT(iteration - 1) - HT(iteration);
            else
                AS(iteration) = 0;
            end
        end
        AS1 = AS;
        OM(year) = (OMPV * PV + OMWT * WT + OMB * ZB + OMEL * Pel + OMTH * THSmax) * (discount)^(year - 1);
    end

    % Post-simulation calculations
    PEZ1 = Electrolyzer + Electrolyzer_load * Heff;
    for yy = 1:8737
        HH(yy) = sum(PEZ1(yy:yy+23));
    end
    DD = min(HH);
    CC = max(HH);

    HC = (CC - sum(HLoad(101:124))) / 1000;
    DC = (sum(HLoad(101:124)) - DD) / 1000;
    MS = HTmax / 1000;
    AAS = sum(AS1(1:8760)) / 1000;

    LOHCCost = ((8014882.91) + (15683.82 * HC) + (62475.1925 * DC) + (1575.86 * MS) + (377.04 * AAS)) / (AAS * 0.9984);

    EZL = find(Electrolyzer == 0);
    EZLoad(EZL) = cutin * PZ;

    OMT = sum(OM);
    LPST = sum(LPS);
    LHST = sum(LHS);
    LTST = sum(LTS);

    %EPenalty = pf * LPST;
    %HPenalty = hpf * LHST;
    TPenalty = tpf * LTST;

    % Replacement costs
    RCBT = 0;
    if LifeTime / BLT > 1, RCBT = RCBT + CCB * (discount)^(1 * BLT); end
    if LifeTime / BLT > 2, RCBT = RCBT + CCB * (discount)^(2 * BLT); end
    if LifeTime / BLT > 3, RCBT = RCBT + CCB * (discount)^(3 * BLT); end
    if LifeTime / BLT > 4, RCBT = RCBT + CCB * (discount)^(4 * BLT); end

    REZT = 0;
    if LifeTime / EZLT > 1, REZT = REZT + reCPz * (discount)^(1 * EZLT); end
    if LifeTime / EZLT > 2, REZT = REZT + reCPz * (discount)^(2 * EZLT); end
    if LifeTime / EZLT > 3, REZT = REZT + reCPz * (discount)^(3 * EZLT); end
    REZT = REZT * Pel;

    Total_load = sum(Load);
    Total_HLoad = sum(HLoad);
    Unmet1 = LHS;
    UnmetE1 = LPS;
    Supplied_ELoad = Load - UnmetE1;
    Supplied_HLoad = HLoad - Unmet1;
    ELoadSuppliedPercentage1 = sum(Supplied_ELoad) / Total_load;
    HLoadSuppliedPercentage1 = sum(Supplied_HLoad) / Total_HLoad;
    Capacity_Factor = min(ELoadSuppliedPercentage1, HLoadSuppliedPercentage1) - 0.1;

    SP1 = min(Supplied_ELoad ./ Load, Supplied_HLoad ./ HLoad);
    SP2 = min(SP1, HLoad);
    Penalty1 = P1 * sum(SP1 < 0.2);
    Penalty2 = P2 * sum(SP1 < 0.4);
    Penalty3 = P3 * sum(SP1 < 0.6);
    Penalty4 = P4 * sum(SP1 < 0.8);

    CT = CCB + RCBT + CCPV + CCWT + OMT + LifeTime * AAS * 0.9984 * LOHCCost + CCPz + REZT + CCTH + CTH_electric_heater + Penalty1 + Penalty2 + Penalty3 + Penalty4 + TPenalty;
    RealCT = CCB + RCBT + CCPV + CCWT + OMT + LifeTime * AAS * 0.9984 * LOHCCost + CCPz + REZT + CCTH + CTH_electric_heater;
    LCT = CT / LifeTime;
    RealLCT = RealCT / LifeTime;
    sumHLoad = sum(HLoad);
    hydrogen_incentive = 3;
    intencived_CT = (CCB + RCBT + CCPV + CCWT + OMT + LifeTime * 0.9984 * AAS * LOHCCost + CCPz + REZT + CCTH + CTH_electric_heater - hydrogen_incentive * sumHLoad) / LifeTime;

    NewObjectiveFunction = (174595000 + 261665000 * (Capacity_Factor / 0.9) + LCT) / (Capacity_Factor * 1162120) - (10 * 5297.4 / 9423.2);

    % Additional outputs
    ExcessElectricity = max((Excess - thc + LTS), 0);
    Total_Excess_electricity = sum(ExcessElectricity);
    ExcessElectricity_main = Excess;
    ExcessElectricity_main_total = sum(ExcessElectricity_main);
    h_e_Cost = RealLCT / (Capacity_Factor * 1162120) - (10 * 5297.4 / 9423.2);
    PEZ = PEZ1;
    SOC = EB;
    SOH = HT;
    SteelProduction = SP2;
    CapacityFactorReal = Capacity_Factor;
    LCSP = (174595000 + 261665000 * (Capacity_Factor / 0.9) + RealLCT) / (Capacity_Factor * 1162120) - (10 * 5297.4 / 9423.2);
    CBatperton = CCB / (LifeTime * Capacity_Factor * 1162120);
    CRbatperton = RCBT / (LifeTime * Capacity_Factor * 1162120);
    CPVperton = CCPV / (LifeTime * Capacity_Factor * 1162120);
    CWTperton = CCWT / (LifeTime * Capacity_Factor * 1162120);
    TotalOMperton = OMT / (LifeTime * Capacity_Factor * 1162120);
    HStorageperton = LifeTime * AAS * 0.9984 * LOHCCost / (LifeTime * Capacity_Factor * 1162120);
    CEZperton = CCPz / (LifeTime * Capacity_Factor * 1162120);
    CREZperton = REZT / (LifeTime * Capacity_Factor * 1162120);
    CThperton = (CCTH + CTH_electric_heater) / (LifeTime * Capacity_Factor * 1162120);
    Energycostperton = CBatperton + CRbatperton + CPVperton + CWTperton + TotalOMperton + HStorageperton + CEZperton + CREZperton + CThperton;
    cost_of_storage = LOHCCost;
    intencived_LCSP = (174595000 + 261665000 * (Capacity_Factor / 0.9) + intencived_CT) / (Capacity_Factor * 1162120);
    SEL = Supplied_ELoad - Electrolyzer_load;
    Penalty_optimum = [Penalty1, Penalty2, Penalty3, Penalty4];
    SHL = Supplied_HLoad;
    thermal_storage_level = ths;
    thermal_storage_penalty = TPenalty;
    LPS_Total = LPST;
    LHS_Total = LHST;
    Loss_of_thermal_demand = LTS;
    Total_Eload = sum(Load);
    Total_HLoad = sum(HLoad);
    CostOfHydrogen2 = CT / (sum(Supplied_HLoad) + sum(Supplied_ELoad) / 54.6);
    CostOfElectricity2 = CT / (Total_HLoad * 54.6 + Total_Eload);
    PV_Production = PPV;
    WT_Production = PWT;
    BestCost = CT;
    hydrogen_through_storage_opt = AS;
    EX_percent = 100 * (Total_Excess_electricity) / (sum(PV_Production) + sum(WT_Production));
    EX_percent_main = 100 * (ExcessElectricity_main_total) / (sum(PV_Production) + sum(WT_Production));
    LPSP = 100 * LPS_Total / (Total_Eload);
    LHSP = 100 * LHS_Total / (Total_HLoad);
    COE = CT / sum(Total_Eload);
    electurnoff = length(find(PEZ == 0));
    ElecCapacityFactor = 100 * (1 - electurnoff / length(PEZ));
    addedEZLOAD=EZLoad;
    

    outputs = struct('PV', PV, 'WT', WT, 'ZB', ZB, 'Pel', Pel, 'HTmax', HTmax, 'THSmax', THSmax, ...
        'ObjectiveFunction', NewObjectiveFunction, 'LCSP', LCSP, 'CapacityFactorReal', CapacityFactorReal, ...
        'ExcessElectricity', ExcessElectricity, 'Total_Excess_electricity', Total_Excess_electricity, ...
        'ExcessElectricity_main', ExcessElectricity_main, 'ExcessElectricity_main_total', ExcessElectricity_main_total, ...
        'h_e_Cost', h_e_Cost, 'PEZ', PEZ, 'SOC', SOC, 'SOH', SOH, 'SteelProduction', SteelProduction, ...
        'CBatperton', CBatperton, 'CRbatperton', CRbatperton, 'CPVperton', CPVperton, 'CWTperton', CWTperton, ...
        'TotalOMperton', TotalOMperton, 'HStorageperton', HStorageperton, 'CEZperton', CEZperton, ...
        'CREZperton', CREZperton, 'CThperton', CThperton, 'Energycostperton', Energycostperton, ...
        'cost_of_storage', cost_of_storage, 'intencived_LCSP', intencived_LCSP, 'SEL', SEL, ...
        'Penalty_optimum', Penalty_optimum, 'SHL', SHL, 'thermal_storage_level', thermal_storage_level, ...
        'thermal_storage_penalty', thermal_storage_penalty, 'LPS_Total', LPS_Total, 'LHS_Total', LHS_Total, ...
        'Loss_of_thermal_demand', Loss_of_thermal_demand, 'Total_Eload', Total_Eload, 'Total_HLoad', Total_HLoad, ...
        'CostOfHydrogen2', CostOfHydrogen2, 'CostOfElectricity2', CostOfElectricity2, 'PV_Production', PV_Production, ...
        'WT_Production', WT_Production, 'BestCost', BestCost, 'hydrogen_through_storage_opt', hydrogen_through_storage_opt, ...
        'EX_percent', EX_percent, 'EX_percent_main', EX_percent_main, 'LPSP', LPSP, 'LHSP', LHSP, 'COE', COE, ...
        'ElecCapacityFactor', ElecCapacityFactor, 'addedEZLOAD', addedEZLOAD);
end


